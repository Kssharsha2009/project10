var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","167280bf-9844-4424-9f7d-520867bfe58f","68f426ea-25ba-466e-b825-bc78ed331db9","d1c58a9b-1220-4a16-b7f0-138f3cb175f2","eb656de0-c68b-4ef1-b82b-8206c965fd46","16fd10dd-bb55-4824-ad07-00b607f931e7","56a04adf-31b3-44ea-897f-2a7f8292c763","6e519134-f278-4282-a815-7cbf910fecb0","d79ec0b0-337c-46af-8ba5-01d9e41e0363","336266d3-2896-4a86-b789-96913c365ddf","0be4104b-e7ec-448d-9791-2bafd879fbe5","fe0dad8c-85f9-402d-85c2-f2ba78ace672","fc7bda70-8400-4090-b4fc-7c83572833a9","4c60cea0-5764-4bf9-be4c-008986ac91df","4fbcdd73-c0aa-4951-a251-b40b09726df5"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"OPYDwXtJgyJIdRJRpnPVGYXxnMYFRWXy","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"S6_MQybcOP5NdE8urZ74wZlbYUbmpHtv","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"osQ305Kp..KVpJrYFF9C_.aBkbOwP06X","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"167280bf-9844-4424-9f7d-520867bfe58f":{"name":"living_room_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ysHVw5mmZbMIqwDVXi7C.B4OuPqNMHVm/category_backgrounds/living_room.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"ysHVw5mmZbMIqwDVXi7C.B4OuPqNMHVm","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ysHVw5mmZbMIqwDVXi7C.B4OuPqNMHVm/category_backgrounds/living_room.png"},"68f426ea-25ba-466e-b825-bc78ed331db9":{"name":"bg_landscape06_1","sourceUrl":"assets/api/v1/animation-library/gamelab/eoh_kg5NP1Kj0MRPa_OrPsAFMWthREZl/category_backgrounds/bg_landscape06.png","frameSize":{"x":400,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"eoh_kg5NP1Kj0MRPa_OrPsAFMWthREZl","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/eoh_kg5NP1Kj0MRPa_OrPsAFMWthREZl/category_backgrounds/bg_landscape06.png"},"d1c58a9b-1220-4a16-b7f0-138f3cb175f2":{"name":"pot_1","sourceUrl":"assets/api/v1/animation-library/gamelab/fln6pWOUI6ukrHm.51alTz1P0E.4DVPg/category_household_objects/pot.png","frameSize":{"x":146,"y":104},"frameCount":1,"looping":true,"frameDelay":2,"version":"fln6pWOUI6ukrHm.51alTz1P0E.4DVPg","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":146,"y":104},"rootRelativePath":"assets/api/v1/animation-library/gamelab/fln6pWOUI6ukrHm.51alTz1P0E.4DVPg/category_household_objects/pot.png"},"eb656de0-c68b-4ef1-b82b-8206c965fd46":{"name":"video_game_controller_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Gy0gwj2P1IzLIO0D6ZGfPVgtxfpffxWe/category_household_objects/video_game_controller.png","frameSize":{"x":98,"y":63},"frameCount":1,"looping":true,"frameDelay":2,"version":"Gy0gwj2P1IzLIO0D6ZGfPVgtxfpffxWe","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":98,"y":63},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Gy0gwj2P1IzLIO0D6ZGfPVgtxfpffxWe/category_household_objects/video_game_controller.png"},"16fd10dd-bb55-4824-ad07-00b607f931e7":{"name":"cutting_board_1","sourceUrl":"assets/api/v1/animation-library/gamelab/TrY1t6e94Xr.IdZF9wElSoU5rrgs_YV3/category_household_objects/cutting_board.png","frameSize":{"x":145,"y":147},"frameCount":1,"looping":true,"frameDelay":2,"version":"TrY1t6e94Xr.IdZF9wElSoU5rrgs_YV3","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":145,"y":147},"rootRelativePath":"assets/api/v1/animation-library/gamelab/TrY1t6e94Xr.IdZF9wElSoU5rrgs_YV3/category_household_objects/cutting_board.png"},"56a04adf-31b3-44ea-897f-2a7f8292c763":{"name":"","sourceUrl":null,"frameSize":{"x":390,"y":280},"frameCount":1,"looping":true,"frameDelay":12,"version":"daWtDOf.KbLvRaHkJnGxRaGKzxX_eND5","loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":280},"rootRelativePath":"assets/56a04adf-31b3-44ea-897f-2a7f8292c763.png"},"6e519134-f278-4282-a815-7cbf910fecb0":{"name":"_copy_1","sourceUrl":null,"frameSize":{"x":390,"y":280},"frameCount":1,"looping":true,"frameDelay":12,"version":"qZeZ7KXQP.BuD4AgUSUIoU7UnAce7A7p","loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":280},"rootRelativePath":"assets/6e519134-f278-4282-a815-7cbf910fecb0.png"},"d79ec0b0-337c-46af-8ba5-01d9e41e0363":{"name":"sports_scoccer_1","sourceUrl":"assets/api/v1/animation-library/gamelab/AYKgiaNjv0UtbPRP89eUDfF6ChW0HvBm/category_backgrounds/sports_scoccer.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"AYKgiaNjv0UtbPRP89eUDfF6ChW0HvBm","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/AYKgiaNjv0UtbPRP89eUDfF6ChW0HvBm/category_backgrounds/sports_scoccer.png"},"336266d3-2896-4a86-b789-96913c365ddf":{"name":"chrono","sourceUrl":"assets/v3/animations/NwtPwXiqTJSlrLpos_4l_mS-oJTZ4X0eyAN5FvFB-B0/336266d3-2896-4a86-b789-96913c365ddf.png","frameSize":{"x":614,"y":921},"frameCount":1,"looping":true,"frameDelay":4,"version":"Lp1Hyo4CThN9UKglHuVuzQvj5WNG14IN","loadedFromSource":true,"saved":true,"sourceSize":{"x":614,"y":921},"rootRelativePath":"assets/v3/animations/NwtPwXiqTJSlrLpos_4l_mS-oJTZ4X0eyAN5FvFB-B0/336266d3-2896-4a86-b789-96913c365ddf.png"},"0be4104b-e7ec-448d-9791-2bafd879fbe5":{"name":"kid_28_1","sourceUrl":"assets/api/v1/animation-library/gamelab/f6ye.bXgSBRMrSfhPoC_vLi0xg_oTSEZ/category_people/kid_28.png","frameSize":{"x":192,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"f6ye.bXgSBRMrSfhPoC_vLi0xg_oTSEZ","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":192,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/f6ye.bXgSBRMrSfhPoC_vLi0xg_oTSEZ/category_people/kid_28.png"},"fe0dad8c-85f9-402d-85c2-f2ba78ace672":{"name":"blue_hoodie_hands_in_hoodie_1","sourceUrl":"assets/api/v1/animation-library/gamelab/oHutRKHvMqtbkZzU3Q93li3zFkemFiPq/category_people/blue_hoodie_hands_in_hoodie.png","frameSize":{"x":137,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"oHutRKHvMqtbkZzU3Q93li3zFkemFiPq","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":137,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/oHutRKHvMqtbkZzU3Q93li3zFkemFiPq/category_people/blue_hoodie_hands_in_hoodie.png"},"fc7bda70-8400-4090-b4fc-7c83572833a9":{"name":"soccer_bw_1","sourceUrl":"assets/api/v1/animation-library/gamelab/KAKckB.0WJDP55kNGzIZIfW5wf7Rk5mG/category_sports/soccer_bw.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"KAKckB.0WJDP55kNGzIZIfW5wf7Rk5mG","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/KAKckB.0WJDP55kNGzIZIfW5wf7Rk5mG/category_sports/soccer_bw.png"},"4c60cea0-5764-4bf9-be4c-008986ac91df":{"name":"kid_12_1","sourceUrl":"assets/api/v1/animation-library/gamelab/_Rp.lcHXYHhbwtTQIa6YAsjCoptU3wQc/category_people/kid_12.png","frameSize":{"x":242,"y":339},"frameCount":1,"looping":true,"frameDelay":2,"version":"_Rp.lcHXYHhbwtTQIa6YAsjCoptU3wQc","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":242,"y":339},"rootRelativePath":"assets/api/v1/animation-library/gamelab/_Rp.lcHXYHhbwtTQIa6YAsjCoptU3wQc/category_people/kid_12.png"},"4fbcdd73-c0aa-4951-a251-b40b09726df5":{"name":"kid_39_1","sourceUrl":"assets/api/v1/animation-library/gamelab/2VuLLFfL5_BZN2NuF4xY8ybqrF3thjbY/category_people/kid_39.png","frameSize":{"x":236,"y":343},"frameCount":1,"looping":true,"frameDelay":2,"version":"2VuLLFfL5_BZN2NuF4xY8ybqrF3thjbY","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":236,"y":343},"rootRelativePath":"assets/api/v1/animation-library/gamelab/2VuLLFfL5_BZN2NuF4xY8ybqrF3thjbY/category_people/kid_39.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var background = createSprite(200,200);
background.setAnimation("sports_scoccer_1")
var hero = createSprite(200,345,200,345)
hero.shapeColor="red"

var ball=createSprite(200,200,10,10);
ball.shapeColor="black"
ball.setAnimation("soccer_bw_1");
ball.scale=.1

var enemy1 = createSprite(200,250,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var net = createSprite(200,5,200,20)
net.shapeColor="red"

var goal =0;
var death = 0

hero.setAnimation("kid_28_1");
hero.scale=.1;
enemy1.setAnimation("blue_hoodie_hands_in_hoodie_1");
enemy1.scale=.1;
enemy2.setAnimation("kid_12_1");
enemy2.scale=.1
enemy3.setAnimation("kid_39_1");
enemy3.scale=.1;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
   

//background(b);

createEdgeSprites()




enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}
if(hero.isTouching(ball)){
  ball.bounceOff(hero)
}
if(ball.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  ball.x=200
  ball.y=345
  ball=goal+1
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
if(
  hero.isTouching(enemy1)||
  hero.isTouching(enemy2)||
  hero.isTouching(enemy3))
    {hero.x=200;
    y=345
   life=life+1
    }
  
textSize(20)
  fill("blue")
  text("Goals:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("death:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
